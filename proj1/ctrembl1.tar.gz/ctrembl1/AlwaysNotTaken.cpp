#include "AlwaysNotTaken.h"

AlwaysNotTaken :: AlwaysNotTaken(){};

int AlwaysNotTaken :: predict(long long addr) {
  return 0;
}
