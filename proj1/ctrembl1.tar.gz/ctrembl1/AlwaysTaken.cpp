#include "AlwaysTaken.h"

AlwaysTaken :: AlwaysTaken(){};

int AlwaysTaken :: predict(long long addr) {
  return 1;
}
